<?php

require_once plugin_dir_path(__DIR__) . 'utils.php';

$opt = get_option('editor_plus_extensions_styling__enable', true);
$static_file_opt = get_option('ep_generate_static_file');

$is_extension_enabled = $opt === '1' || $opt === true ? true : false;

add_action('before_delete_post', function ($id) {

    $path = "generated_css/editor_plus_css__$id.min.css";

    $css_file_to_delete = plugin_dir_path(__FILE__) . $path;

    wp_delete_file($css_file_to_delete);
});

if ($is_extension_enabled) {

    add_action('init', function () {

        register_meta(
            'post',
            'editor_plus_custom_styling_options_file_version',
            array(
                'show_in_rest' => true,
                'single'       => true,
                'type'         => 'string',
                'default'       => 'initial'
            )
        );

        register_meta(
            'post',
            'editor_plus_custom_styling_options_css',
            array(
                'show_in_rest' => true,
                'single'       => true,
                'type'         => 'string',
                'default'       => '{}'
            )
        );

        # all the copied stylings will be stored here...        

        register_meta(
            'post',
            'editor_plus_copied_stylings',
            array(
                'show_in_rest' => true,
                'single'       => true,
                'type'         => 'string',
                'default'       => '{}'
            )
        );
    });

    add_action('wp_footer', function () use ($static_file_opt) {

        global $post;

        if (!empty($post)) {
            $ID = $post->ID;

            $custom_styling_meta = get_post_meta($ID, 'editor_plus_custom_styling_options_css', TRUE);
            $static_file_ver  = get_post_meta($ID, 'editor_plus_custom_styling_options_file_version', TRUE);

            $decoded_styling = json_decode($custom_styling_meta);

            $css = [];

            if (is_object($decoded_styling)) {


                foreach ($decoded_styling as $clientID => $styling) {

                    $css[] = $styling;
                }

                $css_code = trim(join("\n", array_unique($css)));

                # minifying
                $css_code = editor_plus_minify_css($css_code);

                if ($static_file_opt === 'true' or $static_file_opt === true or $static_file_opt === '1') {

                    $path = "generated_css/editor_plus_css__$ID.min.css";

                    $css_file_path = plugin_dir_path(__FILE__) . $path;

                    $css_file = fopen($css_file_path, 'w');

                    fwrite($css_file, $css_code);

                    $enqueue_path = plugin_dir_url(__FILE__) . $path;

                    if ($css_code !== "") {
                        wp_enqueue_style(
                            'eplus-options',
                            $enqueue_path,
                            [],
                            $static_file_ver
                        );
                    }
                } else {
                    if ($css_code !== "") {
                        echo sprintf(
                            '<style id="ep-custom-options-css">%1$s</style>',
                            $css_code
                        );
                    }
                }
            }
        }
    }, 1, 1);
}

add_filter('body_class', function ($classes) {
    $classes[] = 'eplus_styles';
    return $classes;
});
