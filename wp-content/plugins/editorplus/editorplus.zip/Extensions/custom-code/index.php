<?php

require_once plugin_dir_path(__DIR__) . 'utils.php';
$opt = get_option('editor_plus_extensions_custom_block_code__enable', true);
$is_extension_enabled = $opt === '1' || $opt === true ? true : false;
$static_file_opt = get_option('ep_generate_static_file');

add_action('before_delete_post', function ($id) {

    $path = "generated_css/editor_plus_custom_css_$id.min.css";

    $css_file_to_delete = plugin_dir_path(__FILE__) . $path;

    wp_delete_file($css_file_to_delete);
});

if ($is_extension_enabled) {

    add_action('init', function () {

        register_meta(
            'post',
            'editor_plus_custom_css',
            array(
                'show_in_rest' => true,
                'single'       => true,
                'type'         => 'string',
                'default'       => '{}'
            )
        );

        register_meta(
            'post',
            'editor_plus_custom_css_file_version',
            array(
                'show_in_rest' => true,
                'single'       => true,
                'type'         => 'string',
                'default'       => 'initial'
            )
        );
    });

    add_action('wp_footer', function () use ($static_file_opt) {

        global $post;

        if (!empty($post)) {
            $id = $post->ID;
            $custom_css_meta = get_post_meta($id, 'editor_plus_custom_css', TRUE);
            $static_file_ver = get_post_meta($id, 'editor_plus_custom_css_file_version', TRUE);

            $css = [];


            $decoded_css = json_decode($custom_css_meta);

            if (is_object($decoded_css)) {

                foreach ($decoded_css as $key => $styling) {

                    $css[] = "$styling";
                }

                $css_code = join("\n", array_unique($css));

                # minifying

                $css_code =  editor_plus_minify_css($css_code);


                if ($static_file_opt === 'true' or $static_file_opt === true or $static_file_opt === '1') {

                    $path = "generated_css/editor_plus_custom_css_$id.min.css";

                    $css_file_path = plugin_dir_path(__FILE__) . $path;

                    $css_file = fopen($css_file_path, 'w');

                    fwrite($css_file, $css_code);

                    $enqueue_path = plugin_dir_url(__FILE__) . $path;

                    if ($css_code !== "") {
                        wp_enqueue_style(
                            'eplus-custom-css',
                            $enqueue_path,
                            [],
                            $static_file_ver
                        );
                    }
                } else {
                    if ($css_code !== "") {
                        echo '<style id="ep-custom-css">' . $css_code . '</style>';
                    }
                }
            }
        }
    });
}


//for global css/js
add_action('wp_footer', function () use ($static_file_opt) {

    $css_file_path = plugin_dir_path(__FILE__) . 'dist/global.css';

    $global_css = wp_strip_all_tags(get_option('ep_custom_global_css'));
    $global_version = get_option('ep_custom_global_css_version');

    # minifying
    $global_css = editor_plus_minify_css($global_css);

    if ($static_file_opt === 'true' or $static_file_opt === true or $static_file_opt === '1') {
        $css_file = fopen($css_file_path, 'w');

        fwrite($css_file, $global_css);

        $path = plugin_dir_url(__FILE__) . 'dist/';

        if ($global_css !== "") {
            wp_enqueue_style(
                'e-plus-global-style',
                $path . 'global.css',
                [],
                $global_version
            );
        }
    } else if ($global_css !== "") {
        echo "<style id='editor-plus-global-style'>$global_css</style>";
    }
});
